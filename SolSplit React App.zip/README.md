# SolSplit - A Decentralized Bill Splitting Application

<div align="center">
  <img src="public/SolSplit Logo.png" alt="SolSplit Logo" width="100"/>
</div>

<p align="center">
  <strong>The easiest way to split bills with friends on the Solana blockchain.</strong>
</p>

<p align="center">
  <a href="#✨-key-features">Key Features</a> •
  <a href="#💻-tech-stack">Tech Stack</a> •
  <a href="#🏁-getting-started">Getting Started</a> •
  <a href="#👩‍💻-team-contributions">Team</a>
</p>

---

## 🚀 About The Project

SolSplit is a decentralized application designed to bring clarity, trust, and efficiency to managing shared expenses. It solves the common problems of tracking shared bills by creating a transparent, shared ledger for each group. Our key innovation is the use of a central platform wallet for collections, which removes the need to trust a single group member with funds. Payments are made effortlessly using Solana Pay's QR code technology.

This repository contains the frontend prototype built during our team hackathon.

### Built With
* ![React](https://img.shields.io/badge/React-18.2.0-blue?logo=react)
* ![Create React App](https://img.shields.io/badge/Create_React_App-5.0.1-green?logo=createreactapp)
* ![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-3.4.3-blue?logo=tailwindcss)
* ![JavaScript](https://img.shields.io/badge/JavaScript-ES6-yellow?logo=javascript)
* ![Chart.js](https://img.shields.io/badge/Chart.js-4.4.3-red?logo=chartdotjs)

---

## ✨ Key Features

* **Username/Password Authentication:** A familiar and easy onboarding process for all users.
* **Responsive Dashboard:** A central hub to view key financial information, which works on both desktop and mobile.
* **Dynamic Group Management:**
    * Create and manage up to 5 groups with custom names and categories.
    * Add up to 5 members per group by username and Solana wallet address.
    * Built-in validation to ensure wallet addresses are in the correct format.
    * Ability to delete groups or remove members from an existing group.
* **Multi-Step Bill Splitting Flow:** An intuitive process for adding a bill, splitting it, and confirming the details.
* **Central Platform Wallet:** All payments are directed to a neutral "SolSplit" wallet, increasing trust and transparency.
* **QR Code Generation for Payments:** Utilizes Solana Pay to generate unique QR codes for each debt, allowing for fast, easy, and error-proof mobile payments.
* **Manual Payment Status Tracking:** A "Mark as Paid" feature for group managers to keep the ledger up-to-date.
* **Statistics Page:** A dedicated page with a spending chart and AI-powered financial insights to help users understand their habits.
* **UI/UX Polish:** Includes features like balance privacy toggles, hover animations, and active page highlighting for a professional feel.

---

## 📸 Screenshots

*(Here we can add screenshots of the application's key pages)*

| Login Page | Dashboard | New Split Page |
| :---: | :---: | :---: |
| ![Login Page]() | ![Dashboard]() | ![New Split Page]() |

---

## 🏁 Getting Started

To get a local copy up and running, follow these simple steps.

### Prerequisites

Make sure you have Node.js (version 18 or higher) and npm installed on your machine.

### Installation & Setup

1.  Clone the repository:
    ```bash
    git clone [https://github.com/Phinnybelle/SolSplit.git](https://github.com/Phinnybelle/SolSplit.git)
    ```
2.  Navigate to the project directory:
    ```bash
    cd SolSplit
    ```
3.  Install all the necessary packages:
    ```bash
    npm install
    ```
4.  Start the development server:
    ```bash
    npm start
    ```
The application will be available at `http://localhost:3000`.

---
## 🗺️ Roadmap & Future Enhancements

* [ ] **Full Solana Wallet-Adapter Integration:** Replace the mock login with a real wallet connection.
* [ ] **Backend Integration:** Connect the frontend to a Node.js/MongoDB backend to persist all data.
* [ ] **Real-Time Transaction Confirmation:** Fetch confirmation from the Solana blockchain after a payment is made.
* [ ] **Smart Contract Integration:** Move the group and expense ledger to a Solana Program for full decentralization.
* [ ] **User Notifications:** Implement push notifications for payment requests and confirmations.

---

## Team Contributions

This project is a collaborative effort. The responsibilities are broken down as follows:

* **Phinnybelle:** Login Page & Navbar
* **Faithy:** Dashboard & Add New Group Modal, Group Details modal, Profile Modal, and Confirm Split Page
* **Jemmy:** Add New Bill, Statistics & AI Financial Insight