import { NavLink, useNavigate } from 'react-router-dom';
import { DashboardIcon, StatsIcon } from '../common/Icons';

// Accept the onNewSplitClick prop
const Sidebar = ({ onNewSplitClick }) => {
    const navigate = useNavigate();

    return (
        <nav className="w-64 bg-dark-bg border-r border-card-bg p-4 flex-col fixed h-full hidden md:flex">
            <div className="flex justify-center items-center mb-6">
                <h1 className="text-4xl font-bold">
                    <span className="text-purple-600">Sol</span>
                    <span className="text-green-600">Split</span>
                </h1>
            </div>
        <ul className="flex-grow space-y-2">
                <li>
                    <NavLink 
                        to="/dashboard" 
                        end 
                        className={({ isActive }) => 
                            `nav-link w-full flex items-center p-3 rounded-lg transition-colors ${
                                isActive 
                                ? 'bg-solana-purple text-white' 
                                : 'text-light-gray hover:bg-card-bg hover:text-white'
                            }`
                        }
                    >
                        <DashboardIcon /> Dashboard
                    </NavLink>
                </li>
                <li>
                    {/* The path is now absolute, which fixes the highlighting */}
                        <NavLink 
                        to="/stats" 
                        className={({ isActive }) => 
                            `nav-link w-full flex items-center p-3 rounded-lg transition-colors ${
                                isActive 
                                ? 'bg-solana-purple text-white' 
                                : 'text-light-gray hover:bg-card-bg hover:text-white'
                            }`
                        }
                    >
                        <StatsIcon className="w-6 h-6 mr-3"/> Statistics
                    </NavLink>
                </li>
            </ul>
            <button 
                onClick={() => {
                    onNewSplitClick(); // Call the reset function
                    navigate('/new-split');
                }}
                className="w-full bg-solana-purple text-white font-bold py-3 rounded-lg shadow-lg shadow-solana-purple/20 hover:bg-opacity-90 transition-all">
                New Split
            </button>
        </nav>
    );
};

export default Sidebar;